package pa2;

import java.util.*;

public class TriangularList<E> {
    public List<List<E>> metaList;
    public int size;

    public TriangularList() {
        throw new UnsupportedOperationException("Constructor Not Implemented");
        // Delete the above line, and write your implementation here.
    }

    public E get(int idx) {
        throw new UnsupportedOperationException("Method Not Implemented");
        // Delete the above line, and write your implementation here.
    }

    public void set(int idx, E value) {
        throw new UnsupportedOperationException("Method Not Implemented");
        // Delete the above line, and write your implementation here.
    }

    public void insert(int idx, E value) {
        throw new UnsupportedOperationException("Method Not Implemented");
        // Delete the above line, and write your implementation here.
    }

    public void remove(int idx) {
        throw new UnsupportedOperationException("Method Not Implemented");
        // Delete the above line, and write your implementation here.
    }

    public String toString() {
        throw new UnsupportedOperationException("Method Not Implemented");
        // Delete the above line, and write your implementation here.
    }

    public int size() {
        throw new UnsupportedOperationException("Method Not Implemented");
        // Delete the above line, and write your implementation here.
    }
}
